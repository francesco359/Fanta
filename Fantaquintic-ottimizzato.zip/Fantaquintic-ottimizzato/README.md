# Fantaquintic
Assistente fantacalcio.

## Come funziona l'aggiornamento automatico
- `.github/workflows/update.yml` parte ogni 30 minuti, ma `scripts/should_run.py` lo fa lavorare davvero solo quando serve
  (ogni 30 min nelle 3 ore attorno a un calcio d'inizio, ogni 60 min nelle 24 ore prima, ogni 2 h nelle 72 ore prima, altrimenti ogni 6 h).
  Un avvio manuale (Run workflow) esegue sempre.
- `scripts/update_fantasuite.py` scarica le fonti in parallelo, calcola il consenso sulle formazioni, ricalcola il modello dei minuti
  e riscrive `data/latest.json` (e uno snapshot in `data/history/`) **solo se qualcosa è cambiato**.
- `data/status.json` è il "battito" dell'automazione: fonti ok, avvisi (`warnings`), durata.
- Se nessuna fonte è utilizzabile il job fallisce (GitHub ti manda la notifica) e i dati precedenti restano.
- `scripts/prune_history.py` tiene tutto per 3 giorni, poi 1 snapshot al giorno fino a 30 giorni.

## Ogni giornata
Aggiorna `round` e `fixtures` in `config.json` (il gate orario si basa sui calci d'inizio; se il calendario è scaduto
compare l'avviso `config_calendario_scaduto`). Soglie del consenso modificabili con un blocco opzionale `"consensus"` in `config.json`.

## Test
`python -m unittest discover -s tests` (offline, nessuna rete).
